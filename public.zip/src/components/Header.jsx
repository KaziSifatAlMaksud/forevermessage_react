import React from "react";
import { Link } from "react-router-dom"; // For routing links
import "bootstrap/dist/css/bootstrap.min.css";

const Header = () => {
  return (
    <header>
      <nav>
        <ul>
          {/* Use React Router's Link for navigation */}
          <li>
            <a src="/">Home</a>
          </li>
          <li>
            <a src="/about">About</a>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
