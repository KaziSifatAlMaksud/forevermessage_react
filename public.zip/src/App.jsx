import React from 'react';
import './App.css';
import AppRouter from './routes/AppRouter.jsx';
import Header from './components/Header.jsx';

function App() {

  return (
    
    <div>
       hello world
      <Header />
      {/* <AppRouter /> */}
     
    </div>
  )
}

export default App;
