import React from "react";
import Header from "../components/Header.jsx";

const Home = () => {
  return (
    <>
      <Header />
      <h1 style={{ color: '#000' }}>Welcome to the Home Page</h1>

    </>
  );
};

export default Home;
